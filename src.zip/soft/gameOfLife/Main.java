package soft.gameOfLife;

import soft.gameOfLife.ui.GameOfLifeFrame;

public class Main {

    public static void main(String[] args) {

        new GameOfLifeFrame();

    }
}
